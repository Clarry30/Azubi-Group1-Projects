import tkinter as tk
from adminPanel import *
class AdminLogin(tk.Toplevel):
    def __init__(self, master, chatbot):
        super().__init__(master)
        self.title("Admin Login")

        self.chatbot = chatbot

        self.label_username = tk.Label(self, text="Username:") # Username label for admin panel
        self.label_password = tk.Label(self, text="Password:") # Password label for admin panel
        self.entry_username = tk.Entry(self) # Entry box for user input
        self.entry_password = tk.Entry(self, show="*")
        self.button_login = tk.Button(self, text="Login", command=self.login) # Login button

        # Padding for labels and button
        self.label_username.pack(pady=10)
        self.entry_username.pack(pady=10)
        self.label_password.pack(pady=10)
        self.entry_password.pack(pady=10)
        self.button_login.pack(pady=10)

    def login(self):
        # Get user input for username and password
        username = self.entry_username.get()
        password = self.entry_password.get()

        # Check if the admin credentials are correct
        if username == "admin" and password == "password":
            self.destroy() # Close admin panel
            AdminPanel(self.master, self.chatbot)
        else:
            tk.messagebox.showerror("Error", "Invalid credentials") # Message box to handle invalid credentials