from tkinter import messagebox
import tkinter as tk
class AdminPanel(tk.Toplevel):
    def __init__(self, master, chatbot):
        super().__init__(master)
        self.title("Admin Panel")

        self.chatbot = chatbot

        self.label_question = tk.Label(self, text="Question:")
        self.label_response = tk.Label(self, text="Response:")
        self.entry_question = tk.Entry(self)
        self.entry_response = tk.Entry(self)
        self.button_add = tk.Button(self, text="Add/Edit", command=self.add_edit_response)

        self.label_question.pack(pady=10)
        self.entry_question.pack(pady=10)
        self.label_response.pack(pady=10)
        self.entry_response.pack(pady=10)
        self.button_add.pack(pady=10)

    def add_edit_response(self):
        question = self.entry_question.get()
        response = self.entry_response.get()

        if question and response:
            self.chatbot.add_response(question, response)
            messagebox.showinfo("Success", "Question/Response added/edited successfully")
        else:
            messagebox.showerror("Error", "Question and Response cannot be empty")
