class SimpleChatbot:
    def __init__(self):
        self.qa_pairs = {
            "azubi africa": "Azubi Africa is an organization that offers a Cloud Engineering Program designed to provide individuals with the knowledge and practical skills needed to excel in the field of cloud engineering.",
            "cloud engineering": "The Cloud Engineering Program at Azubi Africa is designed to equip participants with in-depth knowledge and practical skills for constructing, implementing, and designing robust cloud architectures. It includes instructor-led classes, personalized career support, real work experience, and flexible payment options.",
            "career prospects": "Cloud Engineering offers a thriving career choice with high demand and continuous growth. As a Cloud Engineer, you can work remotely from anywhere, and it serves as an entry point into the broader world of cloud computing and infrastructure management.",
            "job opportunities": "Cloud engineers can explore various career paths, including Cloud Consultant, DevOps Engineer, Cloud Architect, and more. The program provides a pathway to building a strong portfolio for job opportunities or client engagements in the cloud computing domain.",
            "apply": "To apply, click the 'Apply now' button on the Azubi Africa website, fill in the form, and follow the steps provided.",
            "application process": "The application process involves taking a self-assessment test, uploading an updated CV, entering a 4-week trial and vetting phase, and securing your spot by paying the enrollment fee.",
            "financing scholarship": "Azubi Africa provides two financing options: 'Learn, Earn & Pay Back.' More details can be found here.",
            "remote": "Yes, Cloud Engineering offers remote work opportunities, allowing you to work from various locations and contribute to cloud projects while maintaining a healthy work-life balance.",
            "practical experience": "The program includes real work experience, allowing participants to build an outstanding portfolio of practical projects, showcasing their ability to design, deploy, and manage cloud infrastructure.",
            "support": "Yes, the program provides personalized career support, including career coaching by industry experts, helping participants make a smooth transition into the workforce",
            "duration time ": "The Azubi Africa program lasts for 12 weeks of intensive training, followed by 6 months of job placement support.",
            "instructor teachers": "Azubi Africa has a dedicated team of over 20 certified instructors and industry professionals.",
            "eligibility criteria": "The Azubi Africa program is open to anyone who has a passion for technology and wants to pursue a career in cloud engineering, front-end development, or data analytics. You do not need any prior experience or degree in these fields, but you should have a basic understanding of computer science and good communication skills.",
            "tuition fees payment": "Azubi Africa operates on a 'Learn Now, Pay Later' model. The repayments from their success-based tuition are only 15 percent of your monthly income, with a minimum of €66 per month.",
            "fee": "The Azubi Africa program costs $1,500 for the 12-week training, which includes access to online learning resources, live sessions with instructors, mentorship and feedback, and certification exams. You can also apply for a scholarship or a loan to cover the tuition fee, depending on your eligibility and availability.",
            "career job jobs": "The Azubi Africa program prepares you for a variety of jobs in the tech industry, such as cloud engineer, front-end developer, data analyst, data engineer, data scientist, and more. You will also receive job placement support from the Azubi Africa team, who will help you with resume writing, interview preparation, networking, and career guidance.",
            "Exit": "Goodbye! Have a great day."
        }

    def get_response(self, user_input):
        user_input = user_input.lower()
        if user_input == "exit":
            return self.qa_pairs["Exit"]
        for question, answer in self.qa_pairs.items():
            for word in user_input.split():
                if word in question.split():
                    return answer
        return "I'm sorry, I don't have an answer for that."

    def add_response(self, question, response):
        self.qa_pairs[question] = response