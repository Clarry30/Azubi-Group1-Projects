# Import the necessary modules
import tkinter as tk
from chatbot import *
from adminLogin import *

class ChatGUI:
    def __init__(self, master):
        self.master = master
        master.title("Azubi-GPT")

        self.chatbot = SimpleChatbot()

        self.message_history = tk.Text(master, state=tk.DISABLED)
        self.message_history.pack(padx=10, pady=10)

        self.user_input = tk.Entry(master)
        self.user_input.pack(padx=10, pady=10)

        self.send_button = tk.Button(master, text="Send", command=self.send_message)
        self.send_button.pack(pady=10)

        self.admin_button = tk.Button(master, text="Admin", command=self.show_admin_login)
        self.admin_button.pack(pady=10)

        # Display a welcome message when the window opens
        welcome_message = "Welcome to Azubi-GPT! Please ask a question."
        self.message_history.configure(state=tk.NORMAL)
        self.message_history.insert(tk.END, f"Azubi-GPT: {welcome_message}\n")
        self.message_history.configure(state=tk.DISABLED)

    
    def send_message(self):
        user_input = self.user_input.get()
        self.user_input.delete(0, tk.END)

        response = self.chatbot.get_response(user_input)

        self.message_history.configure(state=tk.NORMAL)
        self.message_history.insert(tk.END, f"You: {user_input}\n")
        self.message_history.insert(tk.END, f"Azubi-GPT: {response}\n")
        self.message_history.configure(state=tk.DISABLED)

    def show_admin_login(self):
        AdminLogin(self.master, self.chatbot)